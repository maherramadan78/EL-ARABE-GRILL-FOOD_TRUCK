import {
  getApp,
  getApps,
  initializeApp
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
import {
  doc,
  getDoc,
  getFirestore,
  serverTimestamp,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";
import {
  getDownloadURL,
  getStorage,
  ref,
  uploadBytes
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-storage.js";

window.firebaseReady = Promise.resolve({
  initializeApp,
  getApp,
  getApps,
  getFirestore,
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL
});

window.dispatchEvent(new Event("firebase-adapter-ready"));
